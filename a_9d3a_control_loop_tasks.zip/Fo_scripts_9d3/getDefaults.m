function defaults = getDefaults()
% This function gets default values for parametersGamma from gammaChirpCompress.m
% Mark Skowronski, December 4, 2012

[GCC,GC,f,fp1,GT,GCpeak,defaults] = gammaChirpCompress([]);

return;

% Bye!