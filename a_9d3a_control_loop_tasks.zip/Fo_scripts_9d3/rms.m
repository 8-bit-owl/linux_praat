function y=rms(x);

y = sqrt(mean(x.^2));
